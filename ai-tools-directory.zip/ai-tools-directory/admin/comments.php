<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin();

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/header.php';

// ✅ Flash message
$status = $_GET['status'] ?? '';
$flashMsg = '';
if ($status === 'deleted') {
    $flashMsg = 'Comment deleted successfully.';
}

// Delete a comment
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $pdo->prepare('DELETE FROM comments WHERE comment_id=?')->execute(array($id));

    // ✅ Redirect with status message
    header("Location: comments.php?status=deleted");
    exit;
}

$stmt = $pdo->query('
    SELECT cm.comment_id, cm.comment, cm.created_at, u.name, t.name AS tool_name
    FROM comments cm
    JOIN users u ON cm.user_id = u.user_id
    JOIN tools t ON cm.tool_id = t.tool_id
    ORDER BY cm.created_at DESC
');

$comments = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h1>Moderate Comments</h1>

<?php if ($flashMsg): ?>
    <p style="padding:10px;border:1px solid #ccc;">
        <?php echo e($flashMsg); ?>
    </p>
<?php endif; ?>

<table border="1" cellpadding="5">
<tr>
    <th>User</th>
    <th>Tool</th>
    <th>Comment</th>
    <th>Date</th>
    <th>Action</th>
</tr>

<?php foreach ($comments as $c): ?>
<tr>
    <td><?php echo e($c['name']); ?></td>
    <td><?php echo e($c['tool_name']); ?></td>
    <td><?php echo e($c['comment']); ?></td>
    <td><?php echo e($c['created_at']); ?></td>
    <td>
        <a href="comments.php?delete=<?php echo (int)$c['comment_id']; ?>"
           onclick="return confirm('Delete this comment?');">
           Delete
        </a>
    </td>
</tr>
<?php endforeach; ?>

</table>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
