<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin();

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/header.php';

// ✅ Show message
$status = $_GET['status'] ?? '';
$flashMsg = '';
if ($status === 'added') {
    $flashMsg = 'Category added successfully.';
} elseif ($status === 'deleted') {
    $flashMsg = 'Category deleted successfully.';
}

// ✅ Add new category (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    if ($name !== '') {
        $stmt = $pdo->prepare('INSERT INTO categories (category_name) VALUES (?)');
        $stmt->execute([$name]);

        // ✅ redirect with message
        header("Location: categories.php?status=added");
        exit;
    }
}

// ✅ Delete category (GET)
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $pdo->prepare('DELETE FROM categories WHERE category_id=?')->execute([$id]);

    // ✅ redirect with message
    header("Location: categories.php?status=deleted");
    exit;
}

$cats = $pdo->query('SELECT * FROM categories ORDER BY category_name')->fetchAll(PDO::FETCH_ASSOC);
?>

<h1>Manage Categories</h1>

<?php if ($flashMsg): ?>
    <p style="padding:10px;border:1px solid #ccc;">
        <?php echo e($flashMsg); ?>
    </p>
<?php endif; ?>

<form method="POST">
    <input type="text" name="name" placeholder="New Category Name" required>
    <button type="submit">Add</button>
</form>

<h3>Existing Categories</h3>
<ul>
<?php foreach ($cats as $c): ?>
    <li>
        <?php echo e($c['category_name']); ?>
        <a href="categories.php?delete=<?php echo (int)$c['category_id']; ?>"
           onclick="return confirm('Delete this category?');">
           Delete
        </a>
    </li>
<?php endforeach; ?>
</ul>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
