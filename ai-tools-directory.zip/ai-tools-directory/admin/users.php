<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin();

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/header.php';


$status = $_GET['status'] ?? '';
$flashMsg = '';

if ($status === 'deleted') {
    $flashMsg = 'User deleted successfully.';
} elseif ($status === 'role_updated') {
    $flashMsg = 'User role updated successfully.';
} elseif ($status === 'self_delete_blocked') {
    $flashMsg = 'You cannot delete your own account.';
} elseif ($status === 'self_role_blocked') {
    $flashMsg = 'You cannot change your own role.';
}


if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];

    $me = current_user();
    $myId = isset($me['user_id']) ? (int)$me['user_id'] : 0;

    
    if ($myId === $id) {
        header("Location: users.php?status=self_delete_blocked");
        exit;
    }

    $pdo->prepare('DELETE FROM users WHERE user_id = ?')->execute([$id]);

    header("Location: users.php?status=deleted");
    exit;
}


if (isset($_GET['role']) && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $role = ($_GET['role'] === 'admin') ? 'admin' : 'user';

    $me = current_user();
    $myId = isset($me['user_id']) ? (int)$me['user_id'] : 0;

   
    if ($myId === $id) {
        header("Location: users.php?status=self_role_blocked");
        exit;
    }

    $pdo->prepare('UPDATE users SET role = ? WHERE user_id = ?')->execute([$role, $id]);

    header("Location: users.php?status=role_updated");
    exit;
}

$users = $pdo->query('SELECT * FROM users ORDER BY created_at DESC')->fetchAll(PDO::FETCH_ASSOC);
?>

<h1>All Users</h1>

<?php if ($flashMsg): ?>
    <p style="padding:10px;border:1px solid #ccc;">
        <?php echo e($flashMsg); ?>
    </p>
<?php endif; ?>

<table border="1" cellpadding="5">
<tr>
    <th>Name</th>
    <th>Email</th>
    <th>Role</th>
    <th>Created</th>
    <th>Actions</th>
</tr>

<?php foreach ($users as $u): ?>
<tr>
    <td><?php echo e($u['name']); ?></td>
    <td><?php echo e($u['email']); ?></td>
    <td><?php echo e($u['role']); ?></td>
    <td><?php echo e($u['created_at']); ?></td>
    <td>
        <?php $uid = (int)$u['user_id']; ?>

        <?php if (($u['role'] ?? '') === 'admin'): ?>
            <a href="users.php?role=user&id=<?php echo $uid; ?>"
               onclick="return confirm('Change this admin to normal user?');">
               Make User
            </a>
        <?php else: ?>
            <a href="users.php?role=admin&id=<?php echo $uid; ?>"
               onclick="return confirm('Make this user an admin?');">
               Make Admin
            </a>
        <?php endif; ?>
        |
        <a href="users.php?delete=<?php echo $uid; ?>"
           onclick="return confirm('Delete this user?');">
           Delete
        </a>
    </td>
</tr>
<?php endforeach; ?>

</table>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
