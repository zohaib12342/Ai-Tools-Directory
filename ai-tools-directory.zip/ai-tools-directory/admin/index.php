<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/header.php';

// Fetch statistics
$tool_count = $pdo->query('SELECT COUNT(*) FROM tools')->fetchColumn();
$user_count = $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
$comment_count = $pdo->query('SELECT COUNT(*) FROM comments')->fetchColumn();
?>

<h1>Admin Dashboard</h1>

<p>Welcome, <?php echo e(current_user()['name'] ?? 'Admin'); ?>!</p>


<h3>Site Overview</h3>
<ul>
    <li>Total Tools: <?php echo $tool_count; ?></li>
    <li>Total Users: <?php echo $user_count; ?></li>
    <li>Total Comments: <?php echo $comment_count; ?></li>
</ul>

<h3>Admin Actions</h3>
<ul>
    <li><a href="tools.php">Manage Tools</a></li>
    <li><a href="categories.php">Manage Categories</a></li>
    <li><a href="comments.php">Moderate Comments</a></li>
    <li><a href="users.php">View Users</a></li>
</ul>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
