<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin();

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/header.php';

$stmt = $pdo->query("
    SELECT t.*, c.category_name
    FROM tools t
    JOIN categories c ON t.category_id = c.category_id
    ORDER BY t.created_at DESC
");
$tools = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ✅ flash message based on URL
$status = $_GET['status'] ?? '';
$flashMsg = '';
if ($status === 'added') $flashMsg = 'Tool added successfully.';
elseif ($status === 'updated') $flashMsg = 'Tool updated successfully.';
elseif ($status === 'deleted') $flashMsg = 'Tool deleted successfully.';
?>

<h1>Manage Tools</h1>

<?php if ($flashMsg): ?>
  <p style="padding:10px;border:1px solid #ccc;">
    <?php echo e($flashMsg); ?>
  </p>
<?php endif; ?>

<p><a href="tool_edit.php">Add New Tool</a></p>

<table border="1" cellpadding="5">
  <tr>
    <th>Name</th>
    <th>Category</th>
    <th>Price</th>
    <th>Rating</th>
    <th>Actions</th>
  </tr>

  <?php if (empty($tools)): ?>
    <tr><td colspan="5">No tools found.</td></tr>
  <?php else: ?>
    <?php foreach ($tools as $t): ?>
      <?php $toolId = (int)($t['tool_id'] ?? 0); ?>
      <tr>
        <td><?php echo e($t['name'] ?? ''); ?></td>
        <td><?php echo e($t['category_name'] ?? ''); ?></td>
        <td><?php echo e($t['price_type'] ?? ''); ?></td>
        <td><?php echo isset($t['avg_rating']) ? (float)$t['avg_rating'] : 0; ?></td>
        <td>
          <a href="tool_edit.php?id=<?php echo $toolId; ?>">Edit</a> |
          <a href="tool_delete.php?id=<?php echo $toolId; ?>"
             onclick="return confirm('Delete this tool?');">
            Delete
          </a>
        </td>
      </tr>
    <?php endforeach; ?>
  <?php endif; ?>
</table>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
