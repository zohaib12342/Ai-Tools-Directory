<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/header.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$editing = $id > 0;

// Fetch categories
$categories = get_categories($pdo);

// Default empty values
$tool = array(
    'name' => '',
    'description' => '',
    'category_id' => '',
    'price_type' => '',
    'link' => '',
    'image' => ''
);

// If editing, load data
if ($editing) {
    $stmt = $pdo->prepare('SELECT * FROM tools WHERE tool_id = ?');
    $stmt->execute(array($id));
    $tool = $stmt->fetch();
    if (!$tool) {
        die('Tool not found.');
    }
}

// Process form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validate();

    $name = $_POST['name'];
    $description = $_POST['description'];
    $category_id = $_POST['category_id'];
    $price_type = $_POST['price_type'];
    $link = $_POST['link'];

    $image = $tool['image'];

    // Handle image upload
    if (!empty($_FILES['image']['name'])) {
        $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $image = 'tool_' . time() . '.' . $ext;
        move_uploaded_file($_FILES['image']['tmp_name'], UPLOAD_DIR . $image);
    }

    if ($editing) {
    $stmt = $pdo->prepare("
        UPDATE tools SET name=?, description=?, category_id=?, price_type=?, link=?, image=? 
        WHERE tool_id=?
    ");
    $stmt->execute(array($name, $description, $category_id, $price_type, $link, $image, $id));

    // ✅ edit message
    redirect('tools.php?status=updated');
} else {
    $stmt = $pdo->prepare("
        INSERT INTO tools (name, description, category_id, price_type, link, image)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute(array($name, $description, $category_id, $price_type, $link, $image));
	}

    // ✅ add message
    redirect('tools.php?status=added');
}
?>

<h1><?php echo $editing ? 'Edit Tool' : 'Add Tool'; ?></h1>

<form method="POST" enctype="multipart/form-data">
    <?php csrf_field(); ?>

    <label>Name:</label><br>
    <input type="text" name="name" value="<?php echo e($tool['name']); ?>" required><br><br>

    <label>Description:</label><br>
    <textarea name="description" required><?php echo e($tool['description']); ?></textarea><br><br>

    <label>Category:</label><br>
    <select name="category_id" required>
        <?php foreach ($categories as $c): ?>
            <option value="<?php echo $c['category_id']; ?>" 
                <?php if ($c['category_id'] == $tool['category_id']) echo 'selected'; ?>>
                <?php echo e($c['category_name']); ?>
            </option>
        <?php endforeach; ?>
    </select><br><br>

    <label>Price Type:</label><br>
    <select name="price_type" required>
        <option value="Free" <?php if ($tool['price_type']=='Free') echo 'selected'; ?>>Free</option>
        <option value="Paid" <?php if ($tool['price_type']=='Paid') echo 'selected'; ?>>Paid</option>
        <option value="Freemium" <?php if ($tool['price_type']=='Freemium') echo 'selected'; ?>>Freemium</option>
    </select><br><br>

    <label>Official Link:</label><br>
    <input type="text" name="link" value="<?php echo e($tool['link']); ?>"><br><br>

    <label>Tool Image:</label><br>
    <input type="file" name="image"><br>
    <?php if ($editing && $tool['image']): ?>
        Current: <?php echo e($tool['image']); ?>
    <?php endif; ?>
    <br><br>

    <button type="submit">Save</button>
</form>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
