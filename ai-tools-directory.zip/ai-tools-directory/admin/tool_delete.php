<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin();
require_once __DIR__ . '/../includes/db.php';

$id = intval($_GET['id']);

$stmt = $pdo->prepare('DELETE FROM tools WHERE tool_id = ?');
$stmt->execute(array($id));


header('Location: tools.php?status=deleted');
exit;
?>
