<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/header.php';

$errors = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validate();

    $email    = trim($_POST['email']);
    $password = $_POST['password'];

    if ($email === '' || $password === '') {
        $errors[] = 'Email and password are required.';
    } else {
       $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ?');
$stmt->execute(array($email));
$user = $stmt->fetch();

if ($user && password_verify($password, $user['password'])) {
    $_SESSION['user'] = $user;

    if (isset($user['role']) && $user['role'] === 'admin') {
        redirect('../admin/index.php');
    }

    redirect('index.php');
} else {
    $errors[] = 'Invalid email or password.';
}

    }
}
?>

<section class="auth-wrapper">
  <div class="auth-card">
    <h1>Login</h1>

    <?php foreach ($errors as $eMsg): ?>
      <p class="error"><?php echo e($eMsg); ?></p>
    <?php endforeach; ?>

    <form method="post">
      <?php csrf_field(); ?>

      <div class="form-group">
        <label>Email</label>
        <input type="email" name="email" required>
      </div>

      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" required>
      </div>

      <button type="submit" class="btn btn-primary btn-full">
        Login
      </button>
    </form>

    <div class="auth-footer">
      Don't have an account?
      <a href="register.php">Create one</a>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
