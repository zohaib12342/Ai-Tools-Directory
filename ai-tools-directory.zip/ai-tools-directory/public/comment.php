<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/functions.php'; // <-- VERY IMPORTANT

require_login();
csrf_validate();

$tool_id = isset($_POST['tool_id']) ? (int)$_POST['tool_id'] : 0;
$comment = trim($_POST['comment']);
$user_id = $_SESSION['user']['user_id'];

if ($comment !== '' && $tool_id > 0) {
    $stmt = $pdo->prepare("
        INSERT INTO comments (user_id, tool_id, comment)
        VALUES (?, ?, ?)
    ");
    $stmt->execute(array($user_id, $tool_id, $comment));
}

// Redirect back to tool page
redirect("tool.php?id=" . $tool_id);
