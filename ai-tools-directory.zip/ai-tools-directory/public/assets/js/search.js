(function () {
  var input = document.getElementById('globalSearch');
  if (!input) return;

  var box = document.getElementById('searchResults');
  var timer = null;
function clearBox() { box.innerHTML = ''; box.style.display = 'none'; }
  
  function showBox() { box.style.display = 'block'; }

  function render(results) {
    var html = '';
    if ((results.categories && results.categories.length) || (results.tools && results.tools.length)) {
      if (results.categories && results.categories.length) {
        html += '<div class="sr-section"><div class="sr-title">Tasks</div>';
        results.categories.forEach(function (c) {
          html += '<a class="sr-item" href="tools.php?category=' + c.category_id + '">'
               +  c.category_name + '</a>';
        });
        html += '</div>';
      }
      if (results.tools && results.tools.length) {
        html += '<div class="sr-section"><div class="sr-title">Tools</div>';
        results.tools.forEach(function (t) {
          html += '<a class="sr-item" href="tool.php?id=' + t.tool_id + '">'
               +  t.name + ' <span class="sr-meta">(' + t.category_name + ' • '
               +  t.price_type + ' • ' + (parseFloat(t.avg_rating)||0).toFixed(1) + '★)</span></a>';
        });
        html += '</div>';
      }
      box.innerHTML = html;
      showBox();
    } else {
      clearBox();
    }
  }

  input.addEventListener('input', function () {
    var q = input.value.trim();
    if (q.length < 2) { clearBox(); return; }
    if (timer) window.clearTimeout(timer);
    timer = window.setTimeout(function () {
      fetch('search.php?q=' + encodeURIComponent(q))
        .then(function (r) { return r.json(); })
        .then(render)
        .catch(function () { clearBox(); });
    }, 250);
  });

  document.addEventListener('click', function (e) {
    if (!box.contains(e.target) && e.target !== input) clearBox();
  });
})();
// === Rating Star Highlight Script ===
document.addEventListener('DOMContentLoaded', function () {
    var form = document.querySelector('.rating-form');
    if (!form) return;

    var stars = form.querySelectorAll('.star');
    var input = document.getElementById('starsInput');
    var current = parseInt(form.getAttribute('data-current') || '0', 10);

    function paint(value) {
        stars.forEach(function (s, index) {
            s.classList.toggle('active', index < value);
        });
    }
    paint(current);

    stars.forEach(function (star) {
        star.addEventListener('mouseover', function () {
            paint(parseInt(star.dataset.value, 10));
        });
        star.addEventListener('mouseout', function () {
            paint(parseInt(input.value || current, 10));
        });
        star.addEventListener('click', function () {
            input.value = star.dataset.value;
            paint(parseInt(star.dataset.value, 10));
        });
    });
});

