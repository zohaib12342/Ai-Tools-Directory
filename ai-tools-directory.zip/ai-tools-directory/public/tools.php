<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/functions.php';

$categories = get_categories($pdo);
require_once __DIR__ . '/../includes/sidebar.php';
$search     = isset($_GET['search']) ? trim($_GET['search']) : '';
$category   = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$price      = isset($_GET['price']) ? $_GET['price'] : '';

$priceTypes = array('Free', 'Paid', 'Freemium');

$where  = array();
$params = array();

if ($search !== '') {
    $where[]        = '(t.name LIKE :q OR t.description LIKE :q)';
    $params[':q']   = '%' . $search . '%';
}
if ($category > 0) {
    $where[]            = 't.category_id = :cat';
    $params[':cat']     = $category;
}
if ($price !== '' && in_array($price, $priceTypes)) {
    $where[]            = 't.price_type = :price';
    $params[':price']   = $price;
}

$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$sql = "
    SELECT t.*, c.category_name
    FROM tools t
    JOIN categories c ON t.category_id = c.category_id
    $whereSql
    ORDER BY t.created_at DESC
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$tools = $stmt->fetchAll();
?>

<section class="section">
    <div class="section-header space-between">
        <h1>Explore AI tools</h1>
    </div>

    <form class="filter-bar" method="get">
        <input type="text" name="search" placeholder="Search by name or keyword"
               value="<?php echo e($search); ?>">

        <select name="category">
            <option value="0">All categories</option>
            <?php foreach ($categories as $cat): ?>
                <option value="<?php echo $cat['category_id']; ?>"
                    <?php if ($cat['category_id'] === $category) echo 'selected'; ?>>
                    <?php echo e($cat['category_name']); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <select name="price">
            <option value="">All pricing</option>
            <?php foreach ($priceTypes as $p): ?>
                <option value="<?php echo $p; ?>" <?php if ($p === $price) echo 'selected'; ?>>
                    <?php echo $p; ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button type="submit" class="btn btn-primary">Filter</button>
    </form>

    <p class="muted">
        <?php echo count($tools); ?> tool(s) found
        <?php if ($search): ?> for "<strong><?php echo e($search); ?></strong>"<?php endif; ?>
    </p>

    <div class="card-grid">
        <?php if ($tools): ?>
            <?php foreach ($tools as $tool): ?>
                <article class="card">
                    <h3><?php echo e($tool['name']); ?></h3>
                    <p class="card-meta">
                        <?php echo e($tool['category_name']); ?> &#8226;
                        <?php echo e($tool['price_type']); ?>
                    </p>
                    <p class="card-text">
                        <?php echo e(mb_strimwidth($tool['description'], 0, 140, '...')); ?>
                    </p>
                    <div class="card-footer">
                        <span class="rating-badge">
                            <?php echo number_format($tool['avg_rating'], 1); ?>★
                            <span class="rating-count">(<?php echo (int)$tool['rating_count']; ?>)</span>
                        </span>
                        <a href="tool.php?id=<?php echo $tool['tool_id']; ?>" class="btn btn-light">Details</a>
                    </div>
                </article>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No tools match your filters.</p>
        <?php endif; ?>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
