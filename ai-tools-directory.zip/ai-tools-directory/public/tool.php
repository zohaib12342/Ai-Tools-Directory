<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// fetch tool
$stmt = $pdo->prepare("
    SELECT t.*, c.category_name
    FROM tools t
    JOIN categories c ON t.category_id = c.category_id
    WHERE t.tool_id = ?
");
$stmt->execute([$id]);
$tool = $stmt->fetch();

if (!$tool) {
    echo '<h2 style="margin-top:100px;text-align:center;">Tool not found.</h2>';
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}

// fetch comments
$cmt = $pdo->prepare("
    SELECT cm.*, u.name
    FROM comments cm
    JOIN users u ON cm.user_id = u.user_id
    WHERE cm.tool_id = ?
    ORDER BY cm.created_at DESC
");
$cmt->execute([$id]);
$comments = $cmt->fetchAll();

// current user rating
$userRating = 0;
if (is_logged_in()) {
    $rs = $pdo->prepare('SELECT stars FROM ratings WHERE tool_id = ? AND user_id = ?');
    $rs->execute([$id, current_user()['user_id']]);
    $val = $rs->fetchColumn();
    if ($val !== false) $userRating = (int)$val;
}
?>

<!-- ✅ FIXED CONTAINER WRAPPER (CENTERED DETAIL PAGE FIX) -->
<div class="container tool-details-container">

    <!-- ✅ TOOL PAGE LAYOUT -->
    <div class="tool-layout">

        <!-- ✅ LEFT MAIN CONTENT -->
        <div class="tool-main">

            <h1><?php echo e($tool['name']); ?></h1>

            <p class="tool-meta">
                <?php echo e($tool['category_name']); ?> • <?php echo e($tool['price_type']); ?>
            </p>

            <div class="tool-rating-display">
                <span class="rating-number"><?php echo number_format($tool['avg_rating'], 1); ?></span>
                <span class="stars">
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                        <span class="star <?php echo ($i <= round($tool['avg_rating'])) ? 'active' : ''; ?>">★</span>
                    <?php endfor; ?>
                </span>
                <span class="rating-count">(<?php echo (int)$tool['rating_count']; ?> ratings)</span>
            </div>

            <p class="tool-description"><?php echo nl2br(e($tool['description'])); ?></p>

            <?php if (!empty($tool['link'])): ?>
                <a href="<?php echo e($tool['link']); ?>" target="_blank" rel="noopener" class="btn btn-primary">
                    Visit official site
                </a>
            <?php endif; ?>

            <!-- ✅ COMMENTS SECTION -->
            <div class="comment-section" style="margin-top:30px;">
                <h2>Comments</h2>

                <?php if ($comments): ?>
                    <div class="comment-list">
                        <?php foreach ($comments as $c): ?>
                            <div class="comment-card">
                                <div class="comment-header">
                                    <strong><?php echo e($c['name']); ?></strong>
                                    <span class="comment-date"><?php echo date('Y-m-d', strtotime($c['created_at'])); ?></span>
                                </div>
                                <p class="comment-text"><?php echo nl2br(e($c['comment'])); ?></p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="muted">No comments yet. Be the first to share your thoughts!</p>
                <?php endif; ?>
            </div>

        </div>

        <!-- ✅ RIGHT SIDE: RATING + COMMENT FORMS -->
        <div class="tool-side">

            <!-- ✅ RATING BOX -->
            <div class="card rating-box">
                <h3>Your Rating</h3>

                <?php if (is_logged_in()): ?>
                    <form method="post" action="rate.php" class="rating-form" data-current="<?php echo $userRating; ?>">
                        <div class="star-row" id="starRow">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <span class="star" data-value="<?php echo $i; ?>">★</span>
                            <?php endfor; ?>
                        </div>

                        <input type="hidden" name="stars" id="starsInput" value="<?php echo $userRating; ?>">
                        <input type="hidden" name="tool_id" value="<?php echo $tool['tool_id']; ?>">
                        <?php csrf_field(); ?>

                        <button type="submit" class="btn btn-primary">Save rating</button>

                        <?php if ($userRating > 0): ?>
                            <p class="muted" style="margin-top:8px;">You rated: <?php echo $userRating; ?>★</p>
                        <?php endif; ?>
                    </form>
                <?php else: ?>
                    <p><a href="login.php">Login</a> to rate this tool.</p>
                <?php endif; ?>
            </div>

            <!-- ✅ COMMENT BOX -->
            <div class="card comment-box">
                <h3>Leave a Comment</h3>

                <?php if (is_logged_in()): ?>
                    <form method="post" action="comment.php">
                        <textarea name="comment" rows="3" maxlength="500" placeholder="Share your experience..." required></textarea>
                        <input type="hidden" name="tool_id" value="<?php echo $tool['tool_id']; ?>">
                        <?php csrf_field(); ?>

                        <button type="submit" class="btn btn-primary" style="margin-top:10px;">
                            Post comment
                        </button>
                    </form>
                <?php else: ?>
                    <p><a href="login.php">Login</a> to comment.</p>
                <?php endif; ?>
            </div>

        </div>

    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
