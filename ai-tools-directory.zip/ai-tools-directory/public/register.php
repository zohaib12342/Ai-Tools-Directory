<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/header.php';

$errors = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validate();

    $name     = trim($_POST['name']);
    $email    = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm  = $_POST['confirm'];

    if ($name === '' || $email === '' || $password === '' || $confirm === '') {
        $errors[] = 'All fields are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email address.';
    } elseif ($password !== $confirm) {
        $errors[] = 'Passwords do not match.';
    } elseif (strlen($password) < 8) {
        $errors[] = 'Password must be at least 8 characters.';
    } else {
        $check = $pdo->prepare('SELECT COUNT(*) FROM users WHERE email = ?');
        $check->execute(array($email));
        if ($check->fetchColumn() > 0) {
            $errors[] = 'Email is already registered.';
        }
    }

    if (!$errors) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare(
            'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, "user")'
        );
        $stmt->execute(array($name, $email, $hash));
        redirect('login.php');
    }
}
?>

<section class="auth-wrapper">
  <div class="auth-card">
    <h1>Create account</h1>

    <?php foreach ($errors as $eMsg): ?>
      <p class="error"><?php echo e($eMsg); ?></p>
    <?php endforeach; ?>

    <form method="post">
      <?php csrf_field(); ?>

      <div class="form-group">
        <label>Name</label>
        <input type="text" name="name" required>
      </div>

      <div class="form-group">
        <label>Email</label>
        <input type="email" name="email" required>
      </div>

      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" required>
      </div>

      <div class="form-group">
        <label>Confirm Password</label>
        <input type="password" name="confirm" required>
      </div>

      <button type="submit" class="btn btn-primary btn-full">
        Sign up
      </button>
    </form>

    <div class="auth-footer">
      Already have an account?
      <a href="login.php">Login</a>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
