<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json; charset=utf-8');

/* ===============================
   READ SEARCH QUERY
================================ */
$q = isset($_GET['q']) ? trim($_GET['q']) : '';

if (mb_strlen($q) < 2) {
    echo json_encode(
        array('categories' => array(), 'tools' => array()),
        JSON_UNESCAPED_UNICODE
    );
    exit;
}

$like = '%' . $q . '%';

/* ===============================
   SEARCH CATEGORIES (TASKS)
================================ */
$stmt = $pdo->prepare("
    SELECT category_id, category_name
    FROM categories
    WHERE category_name LIKE :q
    ORDER BY category_name ASC
    LIMIT 8
");
$stmt->execute(array(':q' => $like));
$categories = $stmt->fetchAll();

/* ===============================
   SEARCH TOOLS
================================ */
$stmt2 = $pdo->prepare("
    SELECT
        t.tool_id,
        t.name,
        t.price_type,
        t.avg_rating,
        c.category_name
    FROM tools t
    JOIN categories c ON t.category_id = c.category_id
    WHERE t.name LIKE :q
       OR t.description LIKE :q
    ORDER BY
        t.avg_rating DESC,
        t.rating_count DESC,
        t.created_at DESC
    LIMIT 10
");
$stmt2->execute(array(':q' => $like));
$tools = $stmt2->fetchAll();

/* ===============================
   OUTPUT JSON
================================ */
echo json_encode(
    array(
        'categories' => $categories,
        'tools' => $tools
    ),
    JSON_UNESCAPED_UNICODE
);
