<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/functions.php';

require_login();
csrf_validate();

$tool_id = $_POST["tool_id"];
$stars = $_POST["stars"];
$user_id = $_SESSION["user"]["user_id"];

// Insert/update rating
$stmt = $pdo->prepare("
    INSERT INTO ratings (user_id, tool_id, stars)
    VALUES (?, ?, ?)
    ON DUPLICATE KEY UPDATE
        stars = VALUES(stars),
        created_at = CURRENT_TIMESTAMP
");
$stmt->execute([$user_id, $tool_id, $stars]);

// Recalculate avg rating
update_tool_rating_stats($pdo, $tool_id);

redirect("tool.php?id=" . $tool_id);
