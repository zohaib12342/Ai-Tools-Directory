<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/functions.php';

/* ===============================
   READ FILTERS (OPTIONAL)
================================ */
$categoryId = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$priceType  = isset($_GET['price']) ? trim($_GET['price']) : '';

$categories = get_categories($pdo);
require_once __DIR__ . '/../includes/sidebar.php';

/* ===============================
   PAGINATION
================================ */
$perPage = 12;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $perPage;

/* ===============================
   BUILD WHERE CLAUSE
================================ */
$where = [];
$params = [];

if ($categoryId > 0) {
    $where[] = 't.category_id = :category';
    $params[':category'] = $categoryId;
}
if ($priceType !== '') {
    $where[] = 't.price_type = :price';
    $params[':price'] = $priceType;
}

$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

/* ===============================
   TOTAL COUNT (WITH FILTERS)
================================ */
$totalStmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM tools t
    $whereSql
");
$totalStmt->execute($params);
$totalTools = (int)$totalStmt->fetchColumn();
$totalPages = (int)ceil($totalTools / $perPage);

/* ===============================
   FETCH TOOLS (WITH FILTERS)
================================ */
$stmt = $pdo->prepare("
    SELECT t.*, c.category_name
    FROM tools t
    JOIN categories c ON t.category_id = c.category_id
    $whereSql
    ORDER BY t.created_at DESC
    LIMIT :limit OFFSET :offset
");

foreach ($params as $k => $v) {
    $stmt->bindValue($k, $v);
}
$stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();

$tools = $stmt->fetchAll();
?>

<!-- HERO -->
<section class="hero">
  <div class="hero-text">
    <h1>Discover the best AI tools in one place</h1>
    <p>
      Search, compare, rate and review AI tools for education,
      content, design, development, automation and more.
    </p>
    <p class="muted">
      Total tools available: <?php echo $totalTools; ?>
    </p>
    <a href="index.php" class="btn btn-primary">Browse all tools</a>
  </div>
</section>

<!-- ALL TOOLS -->
<section class="section">
  <div class="section-header">
    <h2>All tools</h2>
  </div>

  <div class="card-grid">
    <?php if ($tools): ?>
      <?php foreach ($tools as $tool): ?>
        <article class="card">
          <h3><?php echo e($tool['name']); ?></h3>
          <p class="card-meta">
            <?php echo e($tool['category_name']); ?> • <?php echo e($tool['price_type']); ?>
          </p>
          <p class="card-text">
            <?php echo e(mb_strimwidth($tool['description'], 0, 130, '...')); ?>
          </p>
          <div class="card-footer">
            <span class="rating-badge">
              <?php echo number_format((float)$tool['avg_rating'], 1); ?>★
              (<?php echo (int)$tool['rating_count']; ?>)
            </span>
            <a href="tool.php?id=<?php echo $tool['tool_id']; ?>"
               class="btn btn-light">
              View details
            </a>
          </div>
        </article>
      <?php endforeach; ?>
    <?php else: ?>
      <p>No tools found.</p>
    <?php endif; ?>
  </div>

  <!-- PAGINATION -->
  <?php if ($totalPages > 1): ?>
    <div class="pagination">
      <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <a class="<?php echo ($i === $page) ? 'active' : ''; ?>"
           href="index.php?
           <?php echo $categoryId ? 'category='.$categoryId.'&' : ''; ?>
           <?php echo $priceType ? 'price='.urlencode($priceType).'&' : ''; ?>
           page=<?php echo $i; ?>">
          <?php echo $i; ?>
        </a>
      <?php endfor; ?>
    </div>
  <?php endif; ?>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
