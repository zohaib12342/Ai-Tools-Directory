<?php
// Base URL of the public folder
define('BASE_URL', '/ai-tools-directory/public');

// Folder where uploaded images will be stored
define('UPLOAD_DIR', __DIR__ . '/../public/uploads/');

// Database configuration for WAMP
define('DB_HOST', 'localhost');
define('DB_NAME', 'ai_tools_directory');
define('DB_USER', 'root');
define('DB_PASS', '');

// CSRF security token name
define('CSRF_TOKEN_NAME', '_csrf_token');
ini_set('display_errors', 1);
error_reporting(E_ALL);

?>
