<?php

// Escape output safely
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

// Simple redirect helper
function redirect($url) {
    header('Location: ' . $url);
    exit;
}

// Recompute avg rating and rating_count for a tool
function update_tool_rating_stats($pdo, $tool_id) {
    $stmt = $pdo->prepare('SELECT COUNT(*) AS c, AVG(stars) AS a FROM ratings WHERE tool_id = ?');
    $stmt->execute(array($tool_id));
    $row = $stmt->fetch();

    $count = $row ? (int)$row['c'] : 0;
    $avg   = $row && $row['a'] !== null ? (float)$row['a'] : 0;

    $update = $pdo->prepare('UPDATE tools SET avg_rating = ?, rating_count = ? WHERE tool_id = ?');
    $update->execute(array(round($avg, 2), $count, $tool_id));
}

// Get all categories ordered by name
function get_categories($pdo) {
    $stmt = $pdo->query('SELECT * FROM categories ORDER BY category_name');
    return $stmt->fetchAll();
}
?>
