<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Generate CSRF token
function csrf_token() {
    if (!isset($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

// Add hidden token to forms
function csrf_field() {
    echo '<input type="hidden" name="' . CSRF_TOKEN_NAME . '" value="' . csrf_token() . '">';
}

// Validate token on post requests
function csrf_validate() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!isset($_POST[CSRF_TOKEN_NAME]) ||
            $_POST[CSRF_TOKEN_NAME] !== $_SESSION[CSRF_TOKEN_NAME]) {
            die("Security error: Invalid CSRF token");
        }
    }
}
?>
