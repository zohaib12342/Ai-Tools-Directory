<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';


$currentPage = basename($_SERVER['PHP_SELF']);
$isAuthPage = in_array($currentPage, ['login.php', 'register.php']);
?>
<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <title>AI Tools Directory</title>
  <link rel="icon" type="image/x-icon" href="<?php echo BASE_URL; ?>/assets/favicon.ico">

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">
  <script src="<?php echo BASE_URL; ?>/assets/js/main.js" defer></script>
  <script src="<?php echo BASE_URL; ?>/assets/js/search.js" defer></script>
</head>
<body>

<header class="navbar">
  <div class="nav-left">
    <a href="<?php echo BASE_URL; ?>/index.php" class="logo">
      AI Tools Directory
    </a>
    <a href="<?php echo BASE_URL; ?>/tools.php" class="nav-link">
      Explore
    </a>
  </div>

  <div class="nav-search">
    <input
      id="globalSearch"
      type="text"
      placeholder="Search tasks (categories) or tools..."
      autocomplete="off"
    >
    <div id="searchResults" class="search-results"></div>
  </div>

  <div class="nav-right">
    <?php if (is_logged_in()): ?>
      <span class="nav-user">
        Hi, <?php echo e(current_user()['name']); ?>
      </span>

      <?php if (is_admin()): ?>
        <a href="<?php echo BASE_URL; ?>/../admin/index.php" class="nav-link">
          Admin
        </a>
      <?php endif; ?>

      <a href="<?php echo BASE_URL; ?>/logout.php" class="btn btn-secondary">
        Logout
      </a>
    <?php else: ?>
      <a href="<?php echo BASE_URL; ?>/login.php" class="nav-link">
        Login
      </a>
      <a href="<?php echo BASE_URL; ?>/register.php" class="btn btn-primary">
        Sign up
      </a>
    <?php endif; ?>
  </div>
</header>

<!-- ===============================
     MAIN WRAPPER
     Sidebar layout only if NOT auth
================================ -->
<main class="container <?php echo $isAuthPage ? '' : 'grid-layout'; ?>">
