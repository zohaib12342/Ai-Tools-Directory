<?php
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/db.php';

$allCats = get_categories($pdo);
$activeCat   = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$activePrice = isset($_GET['price']) ? $_GET['price'] : '';
$priceTypes  = ['Free','Paid','Freemium'];
?>

<aside class="sidebar">
  <div class="sidebar-section">
    <h4>Categories</h4>
    <ul class="sidebar-list">
      <li>
        <a class="<?php echo $activeCat===0?'active':''; ?>"
           href="index.php<?php echo $activePrice?'?price='.urlencode($activePrice):''; ?>">
          All
        </a>
      </li>

      <?php foreach ($allCats as $c): ?>
        <li>
          <a class="<?php echo $activeCat===(int)$c['category_id']?'active':''; ?>"
             href="index.php?category=<?php echo $c['category_id']; ?>
             <?php echo $activePrice?'&price='.urlencode($activePrice):''; ?>">
            <?php echo e($c['category_name']); ?>
          </a>
        </li>
      <?php endforeach; ?>
    </ul>
  </div>

  <div class="sidebar-section">
    <h4>Pricing</h4>
    <ul class="sidebar-list">
      <li>
        <a class="<?php echo $activePrice===''?'active':''; ?>"
           href="index.php<?php echo $activeCat?'?category='.$activeCat:''; ?>">
          All
        </a>
      </li>

      <?php foreach ($priceTypes as $p): ?>
        <li>
          <a class="<?php echo $activePrice===$p?'active':''; ?>"
             href="index.php?price=<?php echo urlencode($p); ?>
             <?php echo $activeCat?'&category='.$activeCat:''; ?>">
            <?php echo $p; ?>
          </a>
        </li>
      <?php endforeach; ?>
    </ul>
  </div>
</aside>
