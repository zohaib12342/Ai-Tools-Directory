</main>
<footer class="footer">
  <p>&copy; <?php echo date('Y'); ?> AI Tools Directory. All rights reserved.</p>
</footer>
</body>
</html>
